import TodoBoard from "./components/TodoBoard";

function App() {
  return (
    <div className="flex justify-center">
      <TodoBoard />
    </div>
  );
}

export default App;
